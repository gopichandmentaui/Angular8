import {
    Component,
    OnInit
} from '@angular/core';

@Component({
    selector: 'app-pdp-documentation-tab',
    templateUrl: './pdp-documentation-tab.component.html',
    styleUrls: ['./pdp-documentation-tab.component.css']
})
export class PdpDocumentationTabComponent implements OnInit {

    constructor() {}

    ngOnInit() {}

}
