import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdp-specification-tab',
  templateUrl: './pdp-specification-tab.component.html',
  styleUrls: ['./pdp-specification-tab.component.css']
})
export class PdpSpecificationTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
